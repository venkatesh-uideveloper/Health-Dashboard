angular.module('dashboardApp')
    .controller("remedyController", [
        "$scope",
        "doughnut",
        "remedyTickets",
        "remedyLineChart",
        "$state",
        "remedyChart",
        "$window",
        function($scope, doughnut, remedyTickets, remedyLineChart, $state, remedyChart, $window) {



        }
    ]);
